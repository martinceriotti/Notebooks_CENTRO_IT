SELECT [incident].[incident_id],
	[incident].[inc_status],
	[incident].[date_logged],
	DATEPART(WEEK, [incident].[date_logged]) as inc_week_logged,
	DATEPART(MONTH, [incident].[date_logged]) as inc_month_logged,
	DATEPART(QUARTER, [incident].[date_logged]) as inc_quarter_logged,
	DATEPART(YEAR, [incident].[date_logged]) as inc_year_logged,
	DATEPART(WEEKDAY, [incident].[date_logged]) as inc_weekday_num,
	DATENAME(WEEKDAY, [incident].[date_logged]) as inc_weekday_name,
	[incident].[inc_close_date],
	DATEDIFF(day, [incident].[date_logged],	[incident].[inc_close_date]) as inc_resolution_time,
	[usr].[usr_n],
	[usr].[usr_id],
	[usr].[tele],
	[usr].[email_add],
	[usr].[work_mobile],
	[sectn_dept].[sectn_n],
	[bldng].[bldng_n],
	[bldng].[post_town],
	[bldng].[country],
	[bldng].[timezone_id],
	[usr_role].[usr_role_n],
	[assyst_usr].[assyst_usr_n],
	[serv_dept].[serv_dept_n],
	[serv_dept].[serv_dept_id],
	[inc_cat].[inc_cat_n],
	[serv_off].[serv_off_n]
FROM [Assyst].[dbo].[incident],
	[Assyst].[dbo].[usr],
	[Assyst].[dbo].[sectn_dept],
	[Assyst].[dbo].[bldng_room],
	[Assyst].[dbo].[bldng],
	[Assyst].[dbo].[usr_role],
	[Assyst].[dbo].[assyst_usr],
	[Assyst].[dbo].[serv_dept],
	[Assyst].[dbo].[inc_data],
	[Assyst].[dbo].[serv_off],
	[Assyst].[dbo].[inc_cat]
WHERE [incident].[aff_usr_id] = [usr].[usr_id] AND
	[usr].[sectn_dept_id] = [sectn_dept].[sectn_dept_id] AND
	[usr].[bldng_room_id] = [bldng_room].[bldng_room_id] AND
	[bldng_room].[bldng_id] = [bldng].[bldng_id] AND
	[usr].[usr_role_id] = [usr_role].[usr_role_id] AND
	[incident].[inc_resolve_usr] = [assyst_usr].[assyst_usr_id] AND
	[incident].[inc_resolve_svd] = [serv_dept].[serv_dept_id] AND
	[incident].[incident_id] = [inc_data].[incident_id] AND
	[inc_data].[serv_off_id] = [serv_off].[serv_off_id] AND
	[incident].[inc_cat_id] = [inc_cat].[inc_cat_id]
ORDER BY [incident].[date_logged] ASC